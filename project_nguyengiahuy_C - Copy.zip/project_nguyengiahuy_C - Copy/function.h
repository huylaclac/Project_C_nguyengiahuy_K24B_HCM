#ifndef FUNCTION_H
#define FUNCTION_H

#include "datatype.h"

void MainMENU();
void end();
void displayUserMenu();
void displayUsers();
void addUser();

#endif

